Griggorii@gmail.com new flag
libdir=${prefix}/include
Libs: -L${libdir} -lglmshared_shared




0 -  Maintainer: [ root@GriggoriiX64 ]
1 -  Summary: [ griggorii@gmail.com ]
2 -  Name:    [ libglm-dev ]
3 -  Version: [ 0.9.9 ]
4 -  Release: [ 1 ]
5 -  License: [ GPL ]
6 -  Group:   [ video , games , users , kvm , voice , colord , pulse , pulse-access , bluetooth , rdma , irc , playonlinux , wine , virtualbox ]
7 -  Architecture: [ amd64 ]
8 -  Source location: [ glm-master ]
9 -  Alternate source location: [  ]
10 - Requires: [  ]
11 - Provides: [ glm ]
12 - Conflicts: [  ]
13 - Replaces: [ libglm-dev , libglm-doc ]
