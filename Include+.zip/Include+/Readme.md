                                    Griggorii@gmail.com patent include collection

sudo cp -r glm /usr/include
